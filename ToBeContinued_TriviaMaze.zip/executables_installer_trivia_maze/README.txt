Hello and welcome to Trivia Maze!

To play - install the game via the included installer "setup", then run the included TriviaMaze.exe

To uninstall - run the uninstall exe inside of your TriviaMaze folder.

To run the program without installing the game, simply compile the source code and run the TriviaMain.java. 

Have fun! :)